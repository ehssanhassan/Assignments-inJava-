package Ehsan.AbstractFactoryDesignPattern;

public interface ClothingFactory {
    Shirt createShirt();
    Pants createPants();
}
