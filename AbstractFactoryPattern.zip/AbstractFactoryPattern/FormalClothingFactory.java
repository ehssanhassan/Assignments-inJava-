package Ehsan.AbstractFactoryDesignPattern;

public class FormalClothingFactory implements ClothingFactory {
    @Override
    public Shirt createShirt() {
        return new FormalShirt();
    }

    @Override
    public Pants createPants() {
        return new FormalPants();
    }
}
