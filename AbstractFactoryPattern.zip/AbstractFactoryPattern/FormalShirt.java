package Ehsan.AbstractFactoryDesignPattern;

public class FormalShirt implements Shirt {
    @Override
    public void design() {
        System.out.println("Designing Formal Shirt");
    }
}
