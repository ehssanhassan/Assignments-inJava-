package Ehsan.AbstractFactoryDesignPattern;

public interface Shirt {
    void design();
}

