package Ehsan.AbstractFactoryDesignPattern;

public class CasualShirt implements Shirt {
    @Override
    public void design() {
        System.out.println("Designing Casual Shirt");
    }
}
