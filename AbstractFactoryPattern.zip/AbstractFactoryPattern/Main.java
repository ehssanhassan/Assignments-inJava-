package Ehsan.AbstractFactoryDesignPattern;

public class Main {
    public static void main(String[] args) {
        ClothingFactory casualFactory = new CasualClothingFactory();
        Shirt casualShirt = casualFactory.createShirt();
        casualShirt.design();

        Pants casualPants = casualFactory.createPants();
        casualPants.design();

        ClothingFactory formalFactory = new FormalClothingFactory();
        Shirt formalShirt = formalFactory.createShirt();
        formalShirt.design();

        Pants formalPants = formalFactory.createPants();
        formalPants.design();
    }
}
