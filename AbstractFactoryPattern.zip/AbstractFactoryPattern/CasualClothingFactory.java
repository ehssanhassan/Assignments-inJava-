package Ehsan.AbstractFactoryDesignPattern;

public class CasualClothingFactory implements ClothingFactory {
    @Override
    public Shirt createShirt() {
        return new CasualShirt();
    }

    @Override
    public Pants createPants() {
        return new CasualPants();
    }
}