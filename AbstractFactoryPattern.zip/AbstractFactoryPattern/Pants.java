package Ehsan.AbstractFactoryDesignPattern;

public interface Pants {
    void design();
}
