package Ehsan.AbstractFactoryDesignPattern;

public class CasualPants implements Pants {
    @Override
    public void design() {
        System.out.println("Designing Casual Pants");
    }
}
