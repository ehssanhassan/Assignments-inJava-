package Ehsan.AbstractFactoryDesignPattern;
public class FormalPants implements Pants {
    @Override
    public void design() {
        System.out.println("Designing Formal Pants");
    }
}