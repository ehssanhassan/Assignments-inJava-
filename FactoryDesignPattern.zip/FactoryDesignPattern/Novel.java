package Ehsan.factoryDesignPattern;


    public class Novel implements Book {
        @Override
        public void display() {
            System.out.println("This is a novel book.");
        }
    }
    
    

