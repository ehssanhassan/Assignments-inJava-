package Ehsan.factoryDesignPattern;


    public class Cookbook implements Book {
        @Override
        public void display() {
            System.out.println("This is a cookbook.");
        }
    }
    

