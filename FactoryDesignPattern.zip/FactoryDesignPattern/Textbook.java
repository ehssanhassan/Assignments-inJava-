package Ehsan.factoryDesignPattern;

    public class Textbook implements Book {
        @Override
        public void display() {
            System.out.println("This is a textbook.");
        }
    }
    

