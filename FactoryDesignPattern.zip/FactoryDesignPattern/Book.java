package Ehsan.factoryDesignPattern;
    public interface Book {
        void display();
    }

