package Ehsan.factoryMethodDesignPattern;

public class Bike implements Vehicle {
    @Override
    public void manufacture() {
        System.out.println("Manufacturing a bike");
    }
}
