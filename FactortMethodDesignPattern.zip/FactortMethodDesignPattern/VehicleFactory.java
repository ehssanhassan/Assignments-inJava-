package Ehsan.factoryMethodDesignPattern;

public interface VehicleFactory {
    Vehicle createVehicle();
}
