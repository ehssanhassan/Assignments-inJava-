package Ehsan.factoryMethodDesignPattern;
public interface Vehicle {
    void manufacture();
}
